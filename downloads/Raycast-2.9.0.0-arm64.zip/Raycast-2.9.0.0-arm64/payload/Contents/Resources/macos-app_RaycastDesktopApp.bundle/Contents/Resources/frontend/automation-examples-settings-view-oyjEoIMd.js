
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="804c79fb-829b-5181-abeb-3d8cc3872556")}catch(e){}}();
import{k as e}from"./icon-Bz37K5zE.js";import{t}from"./command-icons-DBmxamc6.js";import{t as n}from"./automation-suggestions-DeOx_fse.js";import{i as r,r as i,t as a}from"./use-open-automation-suggestion-DwKqfK3I.js";var o=e();function s(){let e=a(`examples`);return(0,o.jsx)(r,{title:"自动化示例",description:n,icon:t.large.aiAutomation,children:(0,o.jsx)(i,{onSelect:e,showHeading:!1})})}s.displayName=`AutomationExamplesSettingsView`;export{s as AutomationExamplesSettingsView};
//# sourceMappingURL=automation-examples-settings-view-oyjEoIMd.js.map
//# debugId=804c79fb-829b-5181-abeb-3d8cc3872556
