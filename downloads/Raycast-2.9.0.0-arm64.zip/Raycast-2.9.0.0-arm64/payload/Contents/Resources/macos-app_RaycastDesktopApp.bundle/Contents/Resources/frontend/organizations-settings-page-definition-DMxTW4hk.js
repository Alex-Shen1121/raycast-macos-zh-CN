
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="c83026f8-cb8c-5915-9e65-2280566ea72b")}catch(e){}}();
import{n as e}from"./command-icons-DBmxamc6.js";import{n as t}from"./settings-page-definition-utils-CJaufMD7.js";var n=t({description:"管理组织、成员和组织设置。",group:`root`,icon:e.organizations,id:`organizations`,keywords:[`invite`,`members`,`organization`,`org`,`team`,`teams`,`webhooks`],parent:`root`,path:`/organizations`,rootSearchCommand:!0,title:"组织",to:`/organizations`});export{n as t};
//# sourceMappingURL=organizations-settings-page-definition-DMxTW4hk.js.map
//# debugId=c83026f8-cb8c-5915-9e65-2280566ea72b
