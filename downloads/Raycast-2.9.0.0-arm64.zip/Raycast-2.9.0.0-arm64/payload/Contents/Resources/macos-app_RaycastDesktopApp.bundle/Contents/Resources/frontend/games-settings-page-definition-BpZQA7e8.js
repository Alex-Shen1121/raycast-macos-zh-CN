
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="832e46de-ebcd-5c1a-bb02-72d7b28bf82d")}catch(e){}}();
import{W as e}from"./internal-extensions-CPayyaPp.js";import{t}from"./settings-page-definition-utils-CJaufMD7.js";import{t as n}from"./settings-targets-ar-8kZnE.js";var r={gameMode:`game-mode`},i={rows:{gameMode:n({description:"检测到游戏窗口位于前台时，禁用 Raycast 快捷键。",id:r.gameMode,keywords:[`disable hotkeys`],title:"游戏模式"})}},a=t(e,{id:`games`,keywords:[`game mode`,`games`],searchEntries:[]});export{a as n,r,i as t};
//# sourceMappingURL=games-settings-page-definition-BpZQA7e8.js.map
//# debugId=832e46de-ebcd-5c1a-bb02-72d7b28bf82d
