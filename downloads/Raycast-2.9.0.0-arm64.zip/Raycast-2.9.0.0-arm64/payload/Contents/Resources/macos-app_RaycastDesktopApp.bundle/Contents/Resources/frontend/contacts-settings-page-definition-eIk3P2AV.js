
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="4cc53cd1-3c77-5e58-87d6-73d595e6556e")}catch(e){}}();
import{rt as e}from"./internal-extensions-CPayyaPp.js";import{i as t,r as n,t as r}from"./settings-page-definition-utils-CJaufMD7.js";import{t as i}from"./settings-targets-ar-8kZnE.js";var a={sortOrder:`sort-order`},o={rows:{sortOrder:i({description:"按名或姓排序联系人",id:a.sortOrder,keywords:[`sort`,`by`,`order`],title:"排序依据"})}},s=r(e,{id:`contacts`,keywords:[`contacts`],searchEntries:n([t(o.rows.sortOrder,`row`,{search:{row:a.sortOrder}})])});export{s as n,a as r,o as t};
//# sourceMappingURL=contacts-settings-page-definition-eIk3P2AV.js.map
//# debugId=4cc53cd1-3c77-5e58-87d6-73d595e6556e
