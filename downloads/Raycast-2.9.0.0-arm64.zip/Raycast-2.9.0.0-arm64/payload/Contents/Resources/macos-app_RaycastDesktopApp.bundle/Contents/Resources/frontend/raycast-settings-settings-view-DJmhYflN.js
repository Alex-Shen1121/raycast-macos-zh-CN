
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="82f77ece-d4f6-57ec-b9f6-02625c8054f7")}catch(e){}}();
import{k as e}from"./icon-Bz37K5zE.js";import{j as t}from"./internal-extensions-CPayyaPp.js";import{o as n}from"./settings-ui.namespace-D54_AsdZ.js";import{t as r}from"./extension-static-commands-Cy4PKxoB.js";var i=e();function a(){return(0,i.jsxs)(n,{extensionId:t.id,children:[(0,i.jsx)(r,{extensionId:t.id,commandsTitle:"设置",filter:`not-ai-extensions`}),(0,i.jsx)(r,{extensionId:t.id,commandsTitle:"AI 扩展",filter:`ai-extensions`})]})}a.displayName=`RaycastSettingsSettingsView`;export{a as RaycastSettingsSettingsView};
//# sourceMappingURL=raycast-settings-settings-view-DJmhYflN.js.map
//# debugId=82f77ece-d4f6-57ec-b9f6-02625c8054f7
