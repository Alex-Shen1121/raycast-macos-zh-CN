
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="99a05c2b-701b-528d-8876-11fd54d20f0a")}catch(e){}}();
import{k as e}from"./icon-Bz37K5zE.js";import{Y as t}from"./internal-extensions-CPayyaPp.js";import{o as n}from"./settings-ui.namespace-D54_AsdZ.js";import{t as r}from"./extension-static-commands-Cy4PKxoB.js";var i=e();function a(){return(0,i.jsx)(n,{extensionId:t.id,children:(0,i.jsx)(r,{extensionId:t.id,commandsTitle:"词典"})})}a.displayName=`DictionarySettingsView`;export{a as DictionarySettingsView};
//# sourceMappingURL=dictionary-settings-view-C4dRw0ks.js.map
//# debugId=99a05c2b-701b-528d-8876-11fd54d20f0a
