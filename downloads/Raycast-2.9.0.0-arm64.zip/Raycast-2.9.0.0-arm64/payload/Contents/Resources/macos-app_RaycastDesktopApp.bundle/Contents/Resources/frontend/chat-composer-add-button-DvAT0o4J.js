
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="6b728948-7dab-532c-b111-9ea8be3a4ffc")}catch(e){}}();
import{k as e}from"./icon-Bz37K5zE.js";import{t}from"./shortcuts-CslcL67B.js";import{t as n}from"./simple-tooltip-xKJfId8p.js";import{t as r}from"./chat-composer-control-button-DIjFzbOu.js";var i={button:`chat-composer-add-button__button_ca46d`},a=e(),o=`plus-20`;function s({isOpen:e,onPointerDown:s,disabled:c,ref:l}){return(0,a.jsx)(n,{for:(0,a.jsx)(r,{ref:l,icon:o,size:`small`,className:i.button,"aria-label":"添加上下文","data-state":e?`open`:`closed`,onPointerDown:s,disabled:c}),label:"添加上下文",shortcut:t.toggleAboutPanel})}s.displayName=`ChatComposerAddButton`;export{s as t};
//# sourceMappingURL=chat-composer-add-button-DvAT0o4J.js.map
//# debugId=6b728948-7dab-532c-b111-9ea8be3a4ffc
