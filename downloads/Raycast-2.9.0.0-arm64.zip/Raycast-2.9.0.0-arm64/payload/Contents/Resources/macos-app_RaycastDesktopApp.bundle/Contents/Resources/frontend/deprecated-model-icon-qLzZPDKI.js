
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="a3983c57-8298-5fd6-8547-66ec60406f27")}catch(e){}}();
import{k as e,t}from"./icon-Bz37K5zE.js";import{r as n}from"./popover-BR0wGXnr.js";var r=e();function i(){return(0,r.jsx)(n,{for:(0,r.jsx)(t,{name:`warning`,width:12,height:12,color:`var(--red)`,"aria-label":"已弃用"}),side:`top`,children:"已弃用"})}i.displayName=`DeprecatedModelIcon`;export{i as t};
//# sourceMappingURL=deprecated-model-icon-qLzZPDKI.js.map
//# debugId=a3983c57-8298-5fd6-8547-66ec60406f27
