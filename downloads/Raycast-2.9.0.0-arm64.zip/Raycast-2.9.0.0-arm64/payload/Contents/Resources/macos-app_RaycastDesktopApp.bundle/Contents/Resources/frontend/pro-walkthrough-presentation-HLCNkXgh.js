
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="106646e4-823e-578d-aa8c-80e7b6d88034")}catch(e){}}();
var e=[{id:`ai`,label:`Raycast AI`},{id:`dictation`,label:"听写"},{id:`cloud-sync`,label:"云同步"},{id:`translate`,label:"翻译"},{id:`custom-themes`,label:"自定义主题"},{id:`window-management`,label:"自定义窗口管理"}],t=1280;function n({feature:e}){return 760-(e?48:0)}export{t as n,n as r,e as t};
//# sourceMappingURL=pro-walkthrough-presentation-HLCNkXgh.js.map
//# debugId=106646e4-823e-578d-aa8c-80e7b6d88034
